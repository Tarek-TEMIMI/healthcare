# Developer notes
* None
# Developer helper functions
## debugging functions
* ` kcDebugLog ( $data, $module_name ) `  
#### ( Linux user : tail -f kivicare_log.txt )
#### ( Note :  provide read, write permission to kivicare_log.txt )
## error functions
* ` kcErrorLogs ( $data, $module_name ) `
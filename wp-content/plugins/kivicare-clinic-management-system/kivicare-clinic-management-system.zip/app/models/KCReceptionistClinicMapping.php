<?php


namespace App\models;

use App\baseClasses\KCModel;

class KCReceptionistClinicMapping extends KCModel {

	public function __construct()
	{
		parent::__construct('receptionist_clinic_mappings');
	}


}
<a class="tab-link" href="#detail-info" data-iq-toggle="tab" data-iq-tab="prevent" id="detail-info-tab">
    <span class="sidebar-heading-text"> <?php echo esc_html__('User Detail Information', 'kc-lang' ); ?> </span>
    <p><?php echo esc_html__('Please provide you contact details', 'kc-lang' ); ?></p>
</a>
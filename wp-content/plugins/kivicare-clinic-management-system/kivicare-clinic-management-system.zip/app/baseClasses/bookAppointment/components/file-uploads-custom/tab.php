<a class="tab-link" href="#file-uploads-custom" data-iq-toggle="tab" data-iq-tab="prevent" id="file-uploads-custom-tab">
    <span class="sidebar-heading-text"> <?php echo esc_html__('Appointment Extra Data', 'kc-lang' ); ?> </span>
    <p> <?php echo esc_html__('Upload file and description about appointment', 'kc-lang' ); ?> </p>
</a>
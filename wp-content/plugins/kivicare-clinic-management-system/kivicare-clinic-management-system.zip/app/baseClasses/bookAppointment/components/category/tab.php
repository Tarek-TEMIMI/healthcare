<a class="tab-link" href="#category" data-iq-toggle="tab" data-iq-tab="prevent" id="category-tab">
    <span class="sidebar-heading-text"><?php echo esc_html__("Doctor Services", "kc-lang"); ?></span>
    <p> <?php echo esc_html__("Please select a service from below options", "kc-lang"); ?> </p>
</a>

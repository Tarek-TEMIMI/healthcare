<a class="tab-link confirm-page" href="#confirm" data-iq-toggle="tab" data-iq-tab="prevent" id="confirm-tab">
    <span class="sidebar-heading-text"> <?php echo esc_html__('Confirmation', 'kc-lang' ); ?> </span>
    <p> <?php echo esc_html__('Confirm your booking', 'kc-lang' ); ?> </p>
</a>